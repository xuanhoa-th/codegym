# objects
Mã nguồn objects được sử dụng để thực hành tại [CodeGym](https://codegym.vn) 
